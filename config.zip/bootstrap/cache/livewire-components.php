<?php return array (
  'municipio-local-federal-seccion' => 'App\\Http\\Livewire\\MunicipioLocalFederalSeccion',
);