<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::get('/proyecto/{id}/niveles', 'PersonaController@obtenerSelect');

Route::get('/municipio/{id}/niveles', [MunicipioController::class, 'obtenerLocal']);
Route::get('/federal/{id}/niveles', [DistritoFederalController::class, 'obtenerFederal']);
Route::get('/local/{id}/niveles', [DistritoLocalController::class, 'obtenerLocal']);
Route::get('/seccion/{id}/niveles', [SeccionController::class, 'obtenerSeccion']);

//Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
  //  return $request->user();
//});
