

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Mis capacitaciones</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <ul>
                                        <li><?php echo \Session::get('success'); ?></li>
                                    </ul>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <a class="btn btn-info" href="<?php echo e(route('miscapacitaciones.edit', $modulos->id_cap)); ?>"> Regresar</a>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <label for="name">Nombre del modulo.</label>
                                    <?php echo Form::text('nombre', $modulos->nombre , array('class'=>'form-control', 'readonly')); ?>

                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label for="name">Introducción.</label>
                                    <textarea type="text" class="form-control" name="" readonly><?php echo e($modulos->introduccion); ?></textarea>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <label for="name">Desarrollo.</label>
                                    <textarea type="text" class="form-control" name="" readonly><?php echo e($modulos->desarrollo); ?></textarea>
                                </div>
                            </div>
                            <div class="row">.</div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <label for="name">Documentación Anexa.</label><br>
                                    <?php
                                        if($modulos->anexo1 == null){
                                            echo "";
                                        }else{ 
                                            echo "$modulos->anexo1 : <a target='_blank' class='btn btn-info' href='../../../documentosModulos/$modulos->anexo1'>Descargar</a><br>";
                                        }
                                        if($modulos->anexo2 == null){
                                            echo "";
                                        }else{ 
                                            echo "$modulos->anexo2 : <a target='_blank' class='btn btn-info' href='../../../documentosModulos/$modulos->anexo2'>Descargar</a><br>";
                                        }
                                        if($modulos->anexo3 == null){
                                            echo "";
                                        }else{ 
                                            echo "$modulos->anexo3 : <a target='_blank' class='btn btn-info' href='../../../documentosModulos/$modulos->anexo3'>Descargar</a><br>";
                                        }
                                        if($modulos->anexo4 == null){
                                            echo "";
                                        }else{ 
                                            echo "$modulos->anexo4 : <a target='_blank' class='btn btn-info' href='../../../documentosModulos/$modulos->anexo4'>Descargar</a><br>";
                                        }
                                        if($modulos->anexo5 == null){
                                            echo "";
                                        }else{ 
                                            echo "$modulos->anexo5 : <a target='_blank' class='btn btn-info' href='../../../documentosModulos/$modulos->anexo5'>Descargar</a><br>";
                                        }
                                    ?>
                                </div>
                            </div>

                            <!-- Centramos la paginación a la derecha-->
                            <div class="pagination justify-content-end">
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/miscapacitaciones/iniciar.blade.php ENDPATH**/ ?>