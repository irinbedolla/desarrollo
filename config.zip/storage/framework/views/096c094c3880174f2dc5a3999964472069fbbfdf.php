

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Promovidos</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-persona')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('personas.create')); ?>"> Nuevo</a>
                            <?php endif; ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-persona')): ?>
                            <table class="table table-striped mt-2">
                                <thead style="background-color: #4A001F;">
                                    <th style="display: none;">ID</th>
                                    <th style="color: #fff;">Nombre</th>
                                    <th style="color: #fff;">Apellido P</th>
                                    <th style="color: #fff;">Apellido M</th>
                                    <th style="color: #fff;">Telefono</th>
                                    <th style="color: #fff;">Sección</th>
                                    <th style="color: #fff;">Dist. Local</th>
                                    <th style="color: #fff;">Dist. Federal</th>
                                    <th style="color: #fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($persona->id); ?></td>
                                            <td><?php echo e($persona->nombre); ?></td>
                                            <td><?php echo e($persona->primer_apellido); ?></td>
                                            <td><?php echo e($persona->segundo_apellido); ?></td>
                                            <td><?php echo e($persona->telefono1); ?></td>
                                            <td><?php echo e($persona->seccion); ?></td>
                                            <td><?php echo e($persona->distrito_local); ?></td>
                                            <td><?php echo e($persona->distrito_federal); ?></td>
                                                                                        
                                                                                        
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-persona')): ?>
                                            <a class="btn btn-info" href="<?php echo e(route('personas.edit', $persona->id)); ?>">Editar</a>
                                                <?php endif; ?>
                                                <!--Utilizamos las librerías de laravel collective para hacer la 
                                                eliminación más sencilla con un formulario utilizando el metodo DELETE-->
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-persona')): ?>
                                                <?php echo Form::open(['method'=>'DELETE', 'route'=> ['personas.destroy', $persona->id], 'style'=>'display:inline']); ?>

                                                    <?php echo Form::submit('Borrar', ['class'=> 'btn btn-danger']); ?>

                                                <?php echo Form::close(); ?>

                                                <?php endif; ?>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php endif; ?>

                            <!-- Centramos la paginación a la derecha-->
                            <div class="pagination justify-content-end">
                                <?php echo $personas->links(); ?>

                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chavotas\resources\views/personas/index.blade.php ENDPATH**/ ?>