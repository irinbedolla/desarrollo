

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Capacitación</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="text-center">Agregar Modulo</h3>

                            <!--Se realiza la validación de campos para ver si dejó alguno vacío-->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                            <!--<span class="badge badge-danger"><?php echo e($error); ?></span>-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <!--Se realiza el envío de datos con formulario de Laravel Collective-->
                            <?php echo Form::open(array('route'=>'capacitaciones.crear_modulo', 'method'=>'POST', 'files' => true)); ?>

                                <input type="hidden" name="cap" value="<?=$capacitacion->id?>">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label for="name">Nombre</label>
                                            <input type="text" class="form-control" name="nombre" required>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Introducción</label>
                                            <textarea class="form-control" name="introduccion" required></textarea>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Desarrollo</label>
                                            <textarea class="form-control" name="desarrollo" required></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">  
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label>Documento Anexo</label><br>
                                            <?php echo Form::file('anexo1', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label>Documento Anexo</label><br>
                                            <?php echo Form::file('anexo2', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label>Documento Anexo</label><br>
                                            <?php echo Form::file('anexo3', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label>Documento Anexo</label><br>
                                            <?php echo Form::file('anexo4', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                        <div class="form-group">
                                            <label>Documento Anexo</label><br>
                                            <?php echo Form::file('anexo5', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                        </div>
                                    </div>
                                </div>      

                                <div class="row">
                                    <div id="agregar_pregunta"   class="btn btn-secondary" onclick="agregar_pregunta()">Añade Pregunta</div>
                                </div>


                                <div class="row">
                                    <div id="contenedor">
                                        <div id="obra-social-1" class="obra-social">
                                        </div>
                                    </div>
                                </div>                              
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/js/personas/crear.js"></script>
    <script>
         function agregar_pregunta(){
            var contador = $('.obra-social').length + 1;
            var bloque = '<div id="obra-social-' + contador + '" class="row">'+
                '<div class="col-xs-12 col-sm-12 col-md-6"><div class="form-group">'+
                    '<label for="">Pregunta</label>'+
                    '<input type="text" class="form-control" name="pregunta[]" required>'+
                '</div>'+
                '</div>'+
                '<div class="col-xs-12 col-sm-12 col-md-6">'+
                    '<div class="form-group">'+
                        '<label for="">Respuesta 1</label>'+
                        '<input type="text" class="form-control" name="respuesta1[]" required>'+
                    '</div>'+
                '</div>'+
                '<div class="col-xs-12 col-sm-12 col-md-6">'+
                    '<div class="form-group">'+
                        '<label for="">Respuesta 2</label>'+
                        '<input type="text" class="form-control" name="respuesta2[]" required>'+
                    '</div>'+
                '</div>'+
                '<div class="col-xs-12 col-sm-12 col-md-6">'+
                    '<div class="form-group">'+
                        '<label for="">Respuesta 3</label>'+
                        '<input type="text" class="form-control" name="respuesta3[]" required>'+
                    '</div>'+
                '</div>'+
                '<div class="col-xs-12 col-sm-12 col-md-6">'+
                    '<div class="form-group">'+
                        '<label for="">Respuesta 4</label>'+
                        '<input type="text" class="form-control" name="respuesta4[]" required>'+
                    '</div>'+
                '</div>'+
                '<div class="col-xs-12 col-sm-12 col-md-6">'+
                    '<div class="form-group">'+
                        '<label for="">Numero de respuesta correcta</label>'+
                        '<input type="number" class="form-control" name="correcta[]" required>'+
                    '</div>'+
                '</div>';
            $('#contenedor').append(bloque);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/capacitaciones/crear_modulo.blade.php ENDPATH**/ ?>