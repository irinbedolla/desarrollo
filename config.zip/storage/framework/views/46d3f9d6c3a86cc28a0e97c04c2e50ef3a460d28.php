

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Promovidos</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="text-center">Insertar Promovido</h3>

                            <!--Se realiza la validación de campos para ver si dejó alguno vacío-->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                            <!--<span class="badge badge-danger"><?php echo e($error); ?></span>-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <!--Se realiza el envío de datos con formulario de Laravel Collective-->
                            <?php echo Form::model($persona, ['method' => 'PATCH', 'route' => ['personas.update', $persona->id]]); ?>

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="name">Nombre</label>
                                            <?php echo Form::text('nombre', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>
                                    
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Primer Apellido</label>
                                            <?php echo Form::text('primer_apellido', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Segundo Apellido</label>
                                            <?php echo Form::text('segundo_apellido', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Teléfono</label>
                                            <?php echo Form::text('telefono1', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Teléfono 2</label>
                                            <?php echo Form::text('telefono2', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Municipio</label>
                                            <!--<{Form::select('municipios', null, array('class'=>'form-control')) !!}-->
                                            <!--<?php echo Form::select('municipio', $municipios, null, ['class' => 'form-control']); ?> -->
                                            <select id="municipio" name="municipio" class="form-control">
                                            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre_municipio => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                
                                                <option value="<?php echo e($id); ?>" <?php echo e($nombre_municipio==$persona->municipio ? 'selected' : ''); ?>><?php echo e($id); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Distrito Federal</label>
                                            <!--<?php echo Form::text('distrito_federal', null, array('class'=>'form-control')); ?>-->
                                            <select id="distrito_federal" name="distrito_federal" class="form-control">
                                            <?php $__currentLoopData = $distritos_federales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito_federal_id => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                
                                                <option value="<?php echo e($distrito_federal_id-1); ?>" <?php echo e($distrito_federal_id==$persona->distrito_federal ? 'selected' : ''); ?>><?php echo e($id-1); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Distrito Local</label>
                                            <!--<?php echo Form::text('distrito_local', null, array('class'=>'form-control')); ?>-->
                                            <select id="distrito_local" name="distrito_local" class="form-control">
                                            <?php $__currentLoopData = $distritos_locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito_local_id => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                
                                                <option value="<?php echo e($distrito_local_id-1); ?>" <?php echo e($distrito_local_id==$persona->distrito_local ? 'selected' : ''); ?>><?php echo e($id-1); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Sección</label>
                                            <select id="seccion" name="seccion" class="form-control">
                                            <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion_id => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                
                                                <option value="<?php echo e($seccion_id-1); ?>" <?php echo e($seccion_id==$persona->seccion ? 'selected' : ''); ?>><?php echo e($id-1); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <!--<?php echo Form::text('seccion', null, array('class'=>'form-control')); ?>-->

                                        </div>
                                    </div>

                                    
                                    

                                    </div>                                    
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                        <?php echo Form::close(); ?>

                                </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chavotas\resources\views/personas/editar.blade.php ENDPATH**/ ?>