<div>
    

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="name">Nombre</label>
                                            <?php echo Form::text('nombre', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>
                                    
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Primer Apellido</label>
                                            <?php echo Form::text('primer_apellido', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Segundo Apellido</label>
                                            <?php echo Form::text('segundo_apellido', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Teléfono</label>
                                            <?php echo Form::text('telefono1', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Teléfono 2</label>
                                            <?php echo Form::text('telefono2', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Municipio</label>
                                            <select 
                                            wire:model="selectedState"
                                            id="state_id"
                                            class="ring-1 ring-gray-300 w-full rounded-md px-4 py-2 mt-2 outline-none
                                            focus:ring-2 focus:ring-purple-300">
                                            <?php if(!is_null($municipioSeleccionado)): ?>
                                                <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($state->id); ?>"><?php echo e($municipio->nombre_municipio); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <option value="" disabled selected>Debe seleccionar un municipio</option>
                                            <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <input type="hidden" name="id_usuario_registro" value="<?php echo e(Auth::id()); ?>">
                                    </div>
                                    </div>                                    
                                        <button type="submit" class="btn btn-primary">Guardar</button>


</div>
<?php /**PATH C:\xampp\htdocs\sirena\resources\views/livewire/municipio-local-federal-seccion.blade.php ENDPATH**/ ?>