<li class="side-menus <?php echo e(Request::is('*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/home">
        <i class="fas fa-home"></i></i></i><span class="text-dark">Inicio</span>
    </a>
    <?php if(auth()->guard()->check()): ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Super Usuario')): ?>
            <a class="nav-link" href="/usuarios">
                <i class="fas fa-users"></i></i><span class="text-dark">Usuarios</span>
            </a>
            <a class="nav-link" href="/roles">
                <i class="fas fa-user-shield"></i></i><span class="text-dark">Roles</span>
            </a>
            <a class="nav-link" href="/poderes">
                <i class="fas fa-id-card"></i></i><span class="text-dark">Poderes</span>
            </a>
            <a class="nav-link" href="/capacitaciones">
                <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Capacitaciones</span>
            </a>
            <a class="nav-link" href="/miscapacitaciones">
                <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Mis capacitaciones</span>
            </a>
            <a class="nav-link" href="/expedientes">
                <i class="fas fa-folder" aria-hidden="true"></i></i><span class="text-dark">Expediente</span>
            </a>
        <?php endif; ?>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Administrador')): ?>
            <a class="nav-link" href="/usuarios">
                <i class="fas fa-users"></i></i><span class="text-dark">Usuarios</span>
            </a>
            <a class="nav-link" href="/poderes">
                <i class="fas fa-id-card"></i></i><span class="text-dark">Poderes</span>
            </a>
            <a class="nav-link" href="/capacitaciones">
                <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Capacitaciones</span>
            </a>
            <a class="nav-link" href="/miscapacitaciones">
                <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Mis capacitaciones</span>
            </a>
            <a class="nav-link" href="/expedientes">
                <i class="fas fa-folder" aria-hidden="true"></i></i><span class="text-dark">Expediente</span>
            </a>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Auxiliar')): ?>
            <a class="nav-link" href="/poderes">
                <i class="fas fa-id-card"></i></i><span class="text-dark">Poderes</span>
            </a>
            <a class="nav-link" href="/miscapacitaciones">
                <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Mis capacitaciones</span>
            </a>
            <a class="nav-link" href="/expedientes">
                <i class="fas fa-folder" aria-hidden="true"></i></i><span class="text-dark">Expediente</span>
            </a>
        <?php endif; ?>
    <?php endif; ?>
    
    <?php if(auth()->guard()->check()): ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Capacitacion Admin')): ?>
            <a class="nav-link" href="/capacitaciones">
                <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Capacitaciones</span>
            </a>
            <a class="nav-link" href="/expedientes">
                <i class="fas fa-folder" aria-hidden="true"></i></i><span class="text-dark">Expediente</span>
            </a>
        <?php endif; ?>
    <?php endif; ?>

    

    
</li>
<?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/layouts/menu.blade.php ENDPATH**/ ?>