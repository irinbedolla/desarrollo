<li class="side-menus <?php echo e(Request::is('*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/home">
        <i class="fas fa-home"></i></i></i><span class="text-dark">Inicio</span>
    </a>
    <a class="nav-link" href="/usuarios">
        <i class="fas fa-users"></i></i><span class="text-dark">Usuarios</span>
    </a>
    <a class="nav-link" href="/roles">
        <i class="fas fa-user-shield"></i></i><span class="text-dark">Roles</span>
    </a>
    <a class="nav-link" href="/personas">
        <i class="fas fa-id-card"></i></i><span class="text-dark">Promovidos</span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\chavotas\resources\views/layouts/menu.blade.php ENDPATH**/ ?>