<div class="footer-left">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/layouts/footer.blade.php ENDPATH**/ ?>