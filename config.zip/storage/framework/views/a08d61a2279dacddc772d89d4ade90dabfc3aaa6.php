

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Poder</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="text-center">Editar Poder</h3>

                            <!--Se realiza la validación de campos para ver si dejó alguno vacío-->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                            <!--<span class="badge badge-danger"><?php echo e($error); ?></span>-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <!--Se realiza el envío de datos con formulario de Laravel Collective-->
                            <?php echo Form::model($poder, ['method' => 'PATCH', 'files' => true, 'route' => ['poderes.update', $poder ,$poder->id]] ); ?>

                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="name">Nombres</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->nombres); ?>" name="nombresAbogadoAlta" oninput="this.value = this.value.toUpperCase()" required>
                                    </div>
                                </div>
                                
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Apellidos</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->apellidos); ?>" name="apellidosAbogadoAlta" id="apellidosAbogadoAlta" oninput="this.value = this.value.toUpperCase()" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Teléfono</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->telefono); ?>"  name="telefonoAbogadoAlta" maxlength="10" pattern="[0-9]+" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Correo</label>
                                        <input type="email" class="form-control" value="<?php echo e($poder->email); ?>" name="correoAbogadoAlta" id="correoAbogadoAlta" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Empresa</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->empresa); ?>" name="empresaAbogadoAlta" oninput="this.value = this.value.toUpperCase()" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">CURP</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->curp); ?>" aria-label="CURP" name="curpAbogadoAlta"maxlength="18" oninput="this.value = this.value.toUpperCase()" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Domicilio</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->domicilio); ?>" name="domicilioAbogadoAlta" oninput="this.value = this.value.toUpperCase()" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">RFC</label>
                                        <input type="text" class="form-control" placeholder="RFC Empresa" name="RFCAbogadoAlta" maxlength="10" oninput="this.value = this.value.toUpperCase()">
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Fecha vigencia</label>
                                        <input type="date" class="form-control" value="<?php echo e($poder->fechaVigencia); ?>" name="fechaVigenciaAlta" id="fechaVigenciaAlta" min="<?= date("Y-m-d") ?>" required>
                                    </div>
                                </div>
                                
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Industria</label>
                                        <input type="text" class="form-control" value="<?php echo e($poder->industria); ?>" name="industriaAlta" required>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <span class="" id="basic-addon1">*Seleccione la region(nes).</i></i></span>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="moreliaSucursal" value="Si" <?php if($poder->regionMorelia === "Si") echo "checked"  ?>>
                                            <label class="form-check-label" for="flexCheckDefault">Morelia</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="uruapanSucursal" value="Si" <?php if($poder->regionUruapan === "Si") echo "checked"  ?>>
                                            <label class="form-check-label" for="flexCheckChecked">Uruapan</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="zamoraSucursal" value="Si" <?php if($poder->regionZamora === "Si") echo "checked"  ?>>
                                            <label class="form-check-label" for="flexCheckDefault">Zamora</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label for="">Descripción del poder</label>
                                        <textarea class="form-control" aria-describedby="basic-addon1" name="descripcionpoderAlta" required><?php echo e($poder->poder); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="form-group">
                                        <label for="">Estatus</label>
                                        <select class="form-control" name="estatus" required>
                                            <option value="Pendiente" <?php if($poder->estatus === "Pendiente") echo "selected"  ?>>Pendiente</option>
                                            <option value="Validado" <?php if($poder->estatus === "Validado") echo "selected"  ?>>Validado</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label>*Identificación oficial</label><br>
                                        <a target="_blank" class="btn btn-primary" href="../../documentos/<?php echo e($poder->ine); ?>">Existente</a>
                                        <?php echo Form::file('documentoIne', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label>*Documento que acredite la representación</label><br>
                                        <a target="_blank" class="btn btn-primary" href="../../documentos/<?php echo e($poder->representacion); ?>">Existente</a>
                                        <?php echo Form::file('documentoRepresentacion', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label>Anexos</label><br>
                                        <?php
                                            if($poder->anexo === "Sin anexo")
                                                echo "<td>S/A</td>";
                                            else
                                                echo "<a target='_blank'  class='btn btn-primary' href='documentos/$poder->anexo'>PDF</a>";
                                        ?>
                                        <?php echo Form::file('documentoAnexo', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                    </div>
                                </div>

                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <div class="form-group">
                                        <label>Anexos 2</label><br>
                                        <?php
                                            if($poder->cedula === "Sin anexo")
                                                echo "<td>S/A</td>";
                                            else
                                                echo "<a target='_blank' class='btn btn-primary' href='documentos/$poder->cedula'>PDF</a>";
                                        ?>
                                        <?php echo Form::file('documentoPoder', ['class' => 'form-control-file', 'accept' => '.pdf']); ?>

                                    </div>
                                </div>


                                <div>
                                <?php echo Form::open(array('route' => 'poderes.store', 'method' => 'POST')); ?>

                                <input type="hidden" name="id" value="<?php echo e(Auth::id()); ?>">
                                </div>
                                
                                

                                </div>                                    
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <?php echo Form::close(); ?>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/poderes/editar.blade.php ENDPATH**/ ?>