

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Promovidos</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="text-center">Insertar Promovido</h3>

                            <!--Se realiza la validación de campos para ver si dejó alguno vacío-->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                                    <strong>¡Revise los campos!</strong>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                            <!--<span class="badge badge-danger"><?php echo e($error); ?></span>-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <!--Se realiza el envío de datos con formulario de Laravel Collective-->
                            <?php echo Form::open(array('route'=>'personas.store', 'method'=>'POST')); ?>

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="name">Nombre</label>
                                            <?php echo Form::text('nombre', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>
                                    
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Primer Apellido</label>
                                            <?php echo Form::text('primer_apellido', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Segundo Apellido</label>
                                            <?php echo Form::text('segundo_apellido', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Teléfono</label>
                                            <?php echo Form::text('telefono1', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Teléfono 2</label>
                                            <?php echo Form::text('telefono2', null, array('class'=>'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Municipio</label>
                                            <select id="municipio" name="municipio" class="form-control">
                                            <option value=""> -- Municipio --</option>
                                            <?php $__currentLoopData = $municipios_local; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito_local_id => $nombre_municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                
                                                <option value="<?php echo e($nombre_municipio); ?>"><?php echo e($distrito_local_id); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Distrito Local</label>
                                            <select id="distrito_local" name="distrito_local" class="form-control" disabled>
                                            <option value=""> --Primero selecciona un municipio --</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Distrito Federal</label>
                                            <select id="distrito_federal" name="distrito_federal" class="form-control" disabled>
                                                                                           
                                                <option value="">-- Primero selecciona un Distrito Local --</option>
                                            
                                            </select>
                                        </div>
                                    </div>
                                    
                                    

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="">Sección</label>
                                            <select id="seccion" name="seccion" class="form-control" disabled>
                                            
                                                <option value=""> -- Seleccione un municipio -- </option>
                                            
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div>
                                    <?php echo Form::open(array('route' => 'personas.store', 'method' => 'POST')); ?>

                                    <input type="hidden" name="id_usuario_registro" value="<?php echo e(Auth::id()); ?>">
                                    </div>
                                    
                                    

                                    </div>                                    
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                        <?php echo Form::close(); ?>

                                </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/js/personas/crear.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sirena\resources\views/personas/crear.blade.php ENDPATH**/ ?>