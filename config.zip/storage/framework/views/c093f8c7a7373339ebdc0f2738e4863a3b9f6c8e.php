

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Documentos</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-warning" href="<?php echo e(route('capacitaciones.addpersonas', $id)); ?>"> Regresar</a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('aceptar-persona')): ?>
                                <table class="table table-striped mt-1">
                                    <thead style="background-color: #4A001F;">
                                        <th style="display: none;">ID</th>
                                        <th style="color: #fff;">Titulo</th>
                                        <th style="color: #fff;">Nivel Estudios</th>
                                        <th style="color: #fff;">Especialidades</th>
                                        <th style="color: #fff;">Diplomados</th>
                                        <th style="color: #fff;">Seminario</th>
                                        <th style="color: #fff;">Cursos</th>
                                        <th style="color: #fff;">Desarrollo</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td><a target="_blank" href="../../documentosPersonal/<?php echo e($doc->titulo); ?>">PDF</a></td>
                                                <td><a target="_blank" href="../../documentosPersonal/<?php echo e($doc->nivel_estudios); ?>">PDF</a></td>
                                                <?php
                                                if($doc->especialidad == null){
                                                    echo "<td>S/E</td>";
                                                }else{ 
                                                    echo "<td><a target='_blank' href='../../documentosPersonal/$doc->especialidad'>PDF</a></td>";
                                                }
                                                ?>
                                                <?php
                                                if($doc->diplomado == null){
                                                    echo "<td>S/D</td>";
                                                }else{ 
                                                    echo "<td><a target='_blank' href='../../documentosPersonal/$doc->diplomado'>PDF</a></td>";
                                                }
                                                ?>
                                                <?php
                                                if($doc->seminario == null){
                                                    echo "<td>S/S</td>";
                                                }else{ 
                                                    echo "<td><a target='_blank' href='../../documentosPersonal/$doc->seminario'>PDF</a></td>";
                                                }
                                                ?>
                                                <?php
                                                if($doc->cursos == null){
                                                    echo "<td>S/C</td>";
                                                }else{ 
                                                    echo "<td><a target='_blank' href='../../documentosPersonal/$doc->cursos'>PDF</a></td>";
                                                }
                                                ?>
                                                <?php
                                                if($doc->desarrollo == null){
                                                    echo "<td>S/D</td>";
                                                }else{ 
                                                    echo "<td><a target='_blank' href='../../documentosPersonal/$doc->desarrollo'>PDF</a></td>";
                                                }
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                            <!-- Centramos la paginación a la derecha-->
                            <div class="pagination justify-content-end">
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/capacitaciones/documentos_ver.blade.php ENDPATH**/ ?>