<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Comites</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="text-center">Comite Personas</h3>

                            <!--Se realiza el envío de datos con formulario de Laravel Collective-->
                            <div class="row">
                                <a class="btn btn-warning" href="<?php echo e(route('comites.index')); ?>"> Regresar</a>
                                <table class="table table-striped mt-2">
                                    <thead style="background-color: #4A001F;">
                                        <th style="color: #fff;">Nombre</th>
                                        <th style="color: #fff;">Direccion</th>
                                        <th style="color: #fff;">Telefono</th>
                                        <th style="color: #fff;">INE</th>
                                    </thead>
                                   <tbody>
                                       <?php $__currentLoopData = $comite_personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comite_persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($comite_persona->nombre); ?></td>
                                                <td><?php echo e($comite_persona->direccion); ?></td>
                                                <td><?php echo e($comite_persona->telefono); ?></td>
                                                <td><?php echo e($comite_persona->ine); ?></td>
                                            </tr>  
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                                    </tbody>
                                </table>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sirena_prod/resources/views/comite/personas.blade.php ENDPATH**/ ?>