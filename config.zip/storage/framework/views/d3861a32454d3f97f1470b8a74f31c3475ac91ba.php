

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Mis capacitaciones</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <ul>
                                        <li><?php echo \Session::get('success'); ?></li>
                                    </ul>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="card-title"> 
                                <a class="btn btn-info" href="<?php echo e(route('miscapacitaciones.edit', $capacitacion->id)); ?>"> Regresar</a><br>
                            </div>

                            <?php if($estatus == "En curso" || $estatus == "En prueba"): ?>
                                <?php echo Form::open(array('route'=>'miscapacitaciones.guardar_respuestas', 'method'=>'POST')); ?>

                                    <input type="hidden" name="cap" value="<?php echo e($capacitacion->id); ?>">
                                    <input type="hidden" name="mod" value="<?php echo e($mod); ?>">
                                    <div class="row">
                                        <?php $contador = 0; ?>
                                        <?php $__currentLoopData = $encuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-12 col-sm-12 col-md-12">
                                                <label for="name">Pregunta.</label>
                                                <?php echo Form::text('nombre', $encuesta->pregunta , array('class'=>'form-control', 'readonly')); ?>

                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="respuesta<?php echo e($contador); ?>" id="flexRadioDefault1" value="1">
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        <?php echo e($encuesta->respuesta1); ?>

                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="respuesta<?php echo e($contador); ?>" id="flexRadioDefault1" value="2">
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        <?php echo e($encuesta->respuesta2); ?>

                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="respuesta<?php echo e($contador); ?>" id="flexRadioDefault1" value="3">
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        <?php echo e($encuesta->respuesta3); ?>

                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="respuesta<?php echo e($contador); ?>" id="flexRadioDefault1" value="4">
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        <?php echo e($encuesta->respuesta4); ?>

                                                    </label>
                                                </div>
                                            </div>
                                            <?php $contador++; ?>
                                            <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                    </div>

                                <?php echo Form::close(); ?>

                            <?php endif; ?>
                            <!-- Centramos la paginación a la derecha-->
                            <div class="pagination justify-content-end">
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-integral\resources\views/miscapacitaciones/evaluacion.blade.php ENDPATH**/ ?>