<li class="side-menus <?php echo e(Request::is('*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/home">
        <i class="fas fa-home"></i></i></i><span class="text-dark">Inicio</span>
    </a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-usuario')): ?>
    <a class="nav-link" href="/usuarios">
        <i class="fas fa-users"></i></i><span class="text-dark">Usuarios</span>
    </a>
    <?php endif; ?>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-rol')): ?>
    <a class="nav-link" href="/roles">
        <i class="fas fa-user-shield"></i></i><span class="text-dark">Roles</span>
    </a>
    <?php endif; ?>
    <a class="nav-link" href="/personas">
        <i class="fas fa-id-card"></i></i><span class="text-dark">Promovidos</span>
    </a>

    <a class="nav-link" href="/comite">
        <i class="fa fa-suitcase" aria-hidden="true"></i></i><span class="text-dark">Comité</span>
    </a>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sirena_prod/resources/views/layouts/menu.blade.php ENDPATH**/ ?>