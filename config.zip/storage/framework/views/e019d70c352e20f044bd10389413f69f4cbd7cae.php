<div class="footer-left">
    All rights reserved &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sirena_prod/resources/views/layouts/footer.blade.php ENDPATH**/ ?>