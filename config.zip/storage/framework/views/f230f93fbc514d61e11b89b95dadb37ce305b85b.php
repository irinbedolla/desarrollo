<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Comite</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear-persona')): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('comites.create')); ?>"> Nuevo Comite</a>
                            <?php endif; ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver-persona')): ?>
                            <table class="table table-striped mt-2">
                                <thead style="background-color: #4A001F;">
                                    <th style="display: none;">ID</th>
                                    <th style="color: #fff;">Nombre</th>
                                    <th style="color: #fff;">Encargado</th>
                                    <th style="color: #fff;">Telefono</th>
                                    <th style="color: #fff;">Municipio</th>
                                    <th style="color: #fff;">Sección</th>
                                    <th style="color: #fff;">Dist. Local</th>
                                    <th style="color: #fff;">Dist. Federal</th>
                                    <th style="color: #fff;">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $comites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="display: none;"><?php echo e($comite->comite_id); ?></td>
                                            <td><?php echo e($comite->nombre_comite); ?></td>
                                            <td><?php echo e($comite->nombre_encargado); ?></td>
                                            <td><?php echo e($comite->telefono_encargado); ?></td>
                                            <td><?php echo e($comite->municipio); ?></td>
                                            <td><?php echo e($comite->seccion); ?></td>
                                            <td><?php echo e($comite->distrito_local); ?></td>
                                            <td><?php echo e($comite->distrito_federal); ?></td>
                                            <td>
                                                <div class="col-12 d-flex">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('editar-persona')): ?>
                                                    <a class="btn btn-primary" href="<?php echo e(route('comites.show', $comite->comite_id)); ?>">Personas</a>
                                                    <a class="btn btn-info" href="<?php echo e(route('comites.edit', $comite->comite_id)); ?>">Editar</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('borrar-persona')): ?>
                                                    <?php echo Form::open(['method'=>'DELETE', 'route'=> ['comites.destroy', $comite->comite_id], 'style'=>'display:inline']); ?>

                                                        <?php echo Form::submit('Borrar', ['class'=> 'btn btn-danger']); ?>

                                                    <?php echo Form::close(); ?>

                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php endif; ?>

                            <!-- Centramos la paginación a la derecha-->
                            <div class="pagination justify-content-end">
                                <?php echo $comites->links(); ?>

                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sirena_prod/resources/views/comite/index.blade.php ENDPATH**/ ?>